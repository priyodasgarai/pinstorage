<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_settings', function (Blueprint $table) {
            $table->id();
            $table->enum('payment_mode', ['1', '2'])->comment('1:Sandbox,2:Live')->nullable();
            $table->longtext('rezorpay_sandbox_secrect_key')->nullable();
            $table->longtext('rezorpay_sandbox_publishable_key')->nullable();
            $table->longtext('rezorpay_live_secret_key')->nullable();
            $table->longtext('rezorpay_live_publishable_key')->nullable();
            $table->longtext('fcm_api_key')->nullable();
            $table->longtext('system_mail')->nullable();
            $table->bigInteger('size')->nullable();
            $table->tinyInteger('status')->default('1')->comment('0:Inactive,1:Active,3:deleted')->nullable();
            $table->bigInteger('created_by')->nullable();
            $table->bigInteger('updated_by')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_settings');
    }
}
